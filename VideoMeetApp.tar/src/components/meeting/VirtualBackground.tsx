'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Camera, X, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { cn } from '@/lib/utils'

interface VirtualBackgroundProps {
  isOpen: boolean
  onClose: () => void
  currentBackground: string | null
  onBackgroundChange: (background: string | null) => void
}

interface BackgroundOption {
  id: string
  label: string
  type: 'none' | 'blur' | 'gradient'
  value?: string
}

const BACKGROUNDS: BackgroundOption[] = [
  { id: 'none', label: 'None', type: 'none' },
  { id: 'blur-light', label: 'Blur Light', type: 'blur', value: '4px' },
  { id: 'blur-medium', label: 'Blur Medium', type: 'blur', value: '10px' },
  { id: 'blur-heavy', label: 'Blur Heavy', type: 'blur', value: '20px' },
  { id: 'gradient-blue', label: 'Ocean', type: 'gradient', value: 'linear-gradient(135deg, #0f172a, #1e3a5f)' },
  { id: 'gradient-green', label: 'Forest', type: 'gradient', value: 'linear-gradient(135deg, #064e3b, #065f46)' },
  { id: 'gradient-purple', label: 'Galaxy', type: 'gradient', value: 'linear-gradient(135deg, #1e1b4b, #312e81)' },
  { id: 'gradient-warm', label: 'Sunset', type: 'gradient', value: 'linear-gradient(135deg, #7c2d12, #b45309)' },
  { id: 'gradient-gray', label: 'Studio', type: 'gradient', value: 'linear-gradient(135deg, #18181b, #27272a)' },
  { id: 'gradient-teal', label: 'Aurora', type: 'gradient', value: 'linear-gradient(135deg, #042f2e, #0d9488)' },
]

function ThumbnailPreview({ option }: { option: BackgroundOption }) {
  if (option.type === 'none') {
    return (
      <div className="flex h-full w-full items-center justify-center rounded-md bg-zinc-700/60">
        <Camera className="h-4 w-4 text-zinc-400" />
      </div>
    )
  }

  if (option.type === 'blur') {
    return (
      <div
        className="h-full w-full rounded-md overflow-hidden"
        style={{
          position: 'relative',
        }}
      >
        {/* Simulated video frame behind blur */}
        <div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(135deg, #3f3f46, #52525b, #71717a)',
            filter: `blur(${option.value})`,
          }}
        />
      </div>
    )
  }

  if (option.type === 'gradient') {
    return (
      <div
        className="h-full w-full rounded-md"
        style={{ background: option.value }}
      />
    )
  }

  return null
}

export default function VirtualBackground({
  isOpen,
  onClose,
  currentBackground,
  onBackgroundChange,
}: VirtualBackgroundProps) {
  const handleSelect = (option: BackgroundOption) => {
    if (option.type === 'none') {
      onBackgroundChange(null)
    } else {
      onBackgroundChange(option.id)
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 8, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 8, scale: 0.95 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className="absolute bottom-full left-1/2 z-50 mb-3 w-80 -translate-x-1/2"
        >
          <div className="overflow-hidden rounded-xl border border-zinc-700/80 bg-zinc-800 shadow-2xl shadow-black/40">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-zinc-700/60 px-4 py-3">
              <h3 className="text-sm font-semibold text-zinc-100">
                Virtual Background
              </h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="h-6 w-6 text-zinc-400 hover:bg-zinc-700/60 hover:text-zinc-200"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Background Grid */}
            <TooltipProvider delayDuration={300}>
              <div className="grid grid-cols-3 gap-2 p-3">
                {BACKGROUNDS.map((option) => {
                  const isSelected =
                    option.type === 'none'
                      ? currentBackground === null
                      : currentBackground === option.id

                  return (
                    <Tooltip key={option.id}>
                      <TooltipTrigger asChild>
                        <button
                          onClick={() => handleSelect(option)}
                          className={cn(
                            'group relative flex aspect-video cursor-pointer flex-col items-center justify-center rounded-lg border-2 p-1 transition-all duration-200',
                            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-800',
                            isSelected
                              ? 'border-emerald-500 bg-zinc-700/50'
                              : 'border-transparent hover:border-zinc-600 hover:bg-zinc-700/30'
                          )}
                        >
                          {/* Thumbnail */}
                          <div className="h-[50px] w-full overflow-hidden rounded-md">
                            <ThumbnailPreview option={option} />
                          </div>

                          {/* Selected indicator */}
                          {isSelected && (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{
                                type: 'spring',
                                stiffness: 500,
                                damping: 30,
                              }}
                              className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500"
                            >
                              <Check className="h-3 w-3 text-white" strokeWidth={3} />
                            </motion.div>
                          )}

                          {/* Label */}
                          <span className="mt-1.5 text-[10px] font-medium leading-tight text-zinc-400 group-hover:text-zinc-300 transition-colors truncate w-full text-center">
                            {option.label}
                          </span>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent
                        side="top"
                        className="bg-zinc-900 text-zinc-100 border-zinc-700 text-xs font-medium"
                      >
                        {option.label}
                        {option.type === 'blur' && option.value && (
                          <span className="text-zinc-400 ml-1">({option.value})</span>
                        )}
                      </TooltipContent>
                    </Tooltip>
                  )
                })}
              </div>
            </TooltipProvider>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
